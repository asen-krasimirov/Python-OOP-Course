from .animal_base import AnimalBase


class Lion(AnimalBase):
    _needs = 50
