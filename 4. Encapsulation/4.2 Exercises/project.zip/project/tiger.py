from .animal_base import AnimalBase


class Tiger(AnimalBase):
    _needs = 45

