from .animal_base import AnimalBase


class Cheetah(AnimalBase):
    _needs = 60
