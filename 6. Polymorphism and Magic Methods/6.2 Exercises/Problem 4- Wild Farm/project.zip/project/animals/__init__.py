# from project.animals.animal import Animal
# from project.animals.animal import Bird
# from project.animals.animal import Mammal
#
# __all__ = ['Animal', 'Bird', 'Mammal']