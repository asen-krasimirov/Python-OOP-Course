from .mammal import Mammal


class Bear(Mammal):
    pass
