from .mammal import Mammal


class Gorilla(Mammal):
    pass