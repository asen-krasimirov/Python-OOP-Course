from project import Vehicle


class Car(Vehicle):
    DEFAULT_FUEL_CONSUMPTION: int = 3
    pass
