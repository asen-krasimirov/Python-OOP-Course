from project import Car


class SportCar(Car):
    DEFAULT_FUEL_CONSUMPTION: int = 10
    pass
