from project import Car


class FamilyCar(Car):
    pass
