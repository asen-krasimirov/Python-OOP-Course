from project import Vehicle


class Motorcycle(Vehicle):
    pass
