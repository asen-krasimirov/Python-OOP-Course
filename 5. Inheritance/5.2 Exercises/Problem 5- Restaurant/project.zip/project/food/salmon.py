from project.food.main_dish import MainDish


class Salmon(MainDish):
    # TODO: this might be date to overwrite the data from the respective parent
    SALMON_GRAMS = 22

    def __init__(self, name: str, price: float):
        print(self.SALMON_GRAMS)
        super().__init__(name, price, self.SALMON_GRAMS)
