from project.beverage.beverage import Beverage
# from beverage import Beverage


class ColdBeverage(Beverage):
    pass
