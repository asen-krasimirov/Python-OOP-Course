# from project.beverage.beverage import Beverage
# from project.beverage.coffee import Coffee
# from project.beverage.cold_beverage import ColdBeverage
# from project.beverage.hot_beverage import HotBeverage
# from project.beverage.tea import Tea
#
#
# __all__ = [
#     'Beverage',
#     'Coffee',
#     'ColdBeverage',
#     'HotBeverage',
#     'Tea'
# ]