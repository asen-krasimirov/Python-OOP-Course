from project import Wizard


class DarkWizard(Wizard):
    pass
