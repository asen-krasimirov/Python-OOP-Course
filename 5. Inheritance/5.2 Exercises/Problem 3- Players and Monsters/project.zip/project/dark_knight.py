from project import Knight


class DarkKnight(Knight):
    pass
